<?php
return [
    'Bosh sahifa' => 'Home',
    'Xokimiyat haqida' => 'About',
    'Yangiliklar' => 'News',
    'Hududlar' => 'Territories',
    'Saylov-2019' => 'Election-2019',
    'Faoliyat' => 'Activity',
    'Interaktiv xizmatlar' => 'Interaktiv services',
    'Bosh sahifa' => 'Home',
    'Bosh sahifa' => 'Home',
    'Bosh sahifa' => 'Home',
    'Bosh sahifa' => 'Home',
    'Bosh sahifa' => 'Home',
    'Bosh sahifa' => 'Home',
    'Bosh sahifa' => 'Home',
];